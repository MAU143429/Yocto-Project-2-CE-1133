#include <gpio.h>
#include <stdio.h>
#include <unistd.h>

int main() {

    int outputPin1 = 5; // GPIO 5
    int outputPin2 = 6; // GPIO 6
    int outputPin3 = 17; // GPIO 17
    int outputPin4 = 22; // GPIO 22
    int outputPin5 = 27; // GPIO 27
    int inputPin = 24;   // GPIO 24
    int readValue;

    // Configura los pines como salida o entrada
    pinMode(outputPin1, 1); // Pin 5 como salida
    pinMode(outputPin2, 1); // Pin 6 como salida
    pinMode(outputPin3, 1); // Pin 17 como salida
    pinMode(outputPin4, 1); // Pin 22 como salida
    pinMode(outputPin5, 1); // Pin 2 como salida
    pinMode(inputPin, 0);  // Pin 24 como entrada

    // Escribe valores binarios en todos los pines de salida

    printf("Escribiendo valor 1 en el pin %d\n", outputPin1);
    digitalWrite(outputPin1, 1);
    sleep(1); // Espera 1 segundo

    printf("Escribiendo valor 0 en el pin %d\n", outputPin1);
    digitalWrite(outputPin1, 0);
    sleep(1); // Espera 1 segundo

    printf("Escribiendo valor 1 en el pin %d\n", outputPin2);
    digitalWrite(outputPin2, 1);
    sleep(1); // Espera 1 segundo

    printf("Escribiendo valor 0 en el pin %d\n", outputPin2);
    digitalWrite(outputPin2, 0);
    sleep(1); // Espera 1 segundo

    printf("Escribiendo valor 1 en el pin %d\n", outputPin3);
    digitalWrite(outputPin3, 1);
    sleep(1); // Espera 1 segundo

    printf("Escribiendo valor 0 en el pin %d\n", outputPin3);
    digitalWrite(outputPin3, 0);
    sleep(1); // Espera 1 segundo

    printf("Escribiendo valor 1 en el pin %d\n", outputPin4);
    digitalWrite(outputPin4, 1);
    sleep(1); // Espera 1 segundo

    printf("Escribiendo valor 0 en el pin %d\n", outputPin4);
    digitalWrite(outputPin4, 0);
    sleep(1); // Espera 1 segundo

    printf("Escribiendo valor 1 en el pin %d\n", outputPin5);
    digitalWrite(outputPin5, 1);
    sleep(1); // Espera 1 segundo

    printf("Escribiendo valor 0 en el pin %d\n", outputPin5);
    digitalWrite(outputPin5, 0);
    sleep(1); // Espera 1 segundo

    // Establece un parpadeo en todos los pines de salida con una duración total de 5 segundos
    printf("Haciendo parpadear el pin %d durante 5 segundos\n", outputPin1);
    blink(outputPin1, 500, 10); // 500 ms de encendido/apagado, 10 veces (5 segundos)

    printf("Haciendo parpadear el pin %d durante 5 segundos\n", outputPin2);
    blink(outputPin2, 500, 10); // 500 ms de encendido/apagado, 10 veces (5 segundos)

    printf("Haciendo parpadear el pin %d durante 5 segundos\n", outputPin3);
    blink(outputPin3, 500, 10); // 500 ms de encendido/apagado, 10 veces (5 segundos)

    printf("Haciendo parpadear el pin %d durante 5 segundos\n", outputPin4);
    blink(outputPin4, 500, 10); // 500 ms de encendido/apagado, 10 veces (5 segundos)

    printf("Haciendo parpadear el pin %d durante 5 segundos\n", outputPin5);
    blink(outputPin5, 500, 10); // 500 ms de encendido/apagado, 10 veces (5 segundos)

    // Lee el valor del pin 24 y lo muestra en pantalla
    readValue = digitalRead(inputPin);
    printf("El valor leído del pin %d es: %d\n", inputPin, readValue);

    // Libera todos los pines utilizados
    unexportPin(outputPin1);
    unexportPin(outputPin2);
    unexportPin(outputPin3);
    unexportPin(outputPin4);
    unexportPin(outputPin5);
    unexportPin(inputPin);

    return 0;
}