#ifndef GPIO_H
#define GPIO_H


#define INPUT  0        // Definición para modo de entrada
#define OUTPUT 1        // Definición para modo de salida
#define GPIO_OFFSET 512 // Offset para GPIO en Raspberry Pi


// Función para exportar un pin y permitir su acceso
void exportPin(int pin);

// Función para desexportar un pin y liberar su acceso
void unexportPin(int pin);

// Función para configurar el modo de un pin (entrada o salida)
void pinMode(int pin, int mode);

// Función para escribir un valor lógico en un pin de salida
void digitalWrite(int pin, int value);

// Función para leer el valor lógico actual de un pin de entrada
int digitalRead(int pin);

// Función para generar un blink en un pin
void blink(int pin, int duration, int freq);

#endif // GPIO_H
